package datamanagement;

public class StudentUnitRecordList extends java.util.ArrayList<IStudentUnitRecord> {}
